//Code written 11/28/20 By Spencer Baty
//This program simply prints a message
package com.company.Motto;

public class Main {

    public static void main(String[] args) {
        System.out.println("s Sammy’s makes it fun in the sun. s");
    }
}
