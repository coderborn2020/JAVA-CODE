import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * This program will take account information and other data inputted by the user and
 * write it to a .dat file. This will keep functions from the previous assignment for
 * testing purposes.
 */

public class userEntryProgram {

    static Scanner scanner = new Scanner(System.in);
    public static boolean valid;
    public static char setUserProgram;
    public static String userPassword;
    public static String userId;
    private static final String[] mealPlan = new String[]{"Commuter no meal plan", "Commuter with meal plan", "Dorm"};
    private static final String[] userProgram = new String[]{"Business program", "Lasers program", "Networking program",
            "Programming classes", "Robotics program", "Social Media program"};
    public static int setMealPlan;
    public static int[] answer = new int[]{1,2,3};
    static PrintWriter pw;
    public static int x;
    public static int i;
    public static int ctr;
    public static int iData2;
    public static String iUsername;
    public static String iPassword;
    public static String iMealPlan;
    public static String iStatus;

    static Scanner recordScanner;
    static boolean eof = false;

    public static void main(String[] args) throws FileNotFoundException {

        userInfo userinfo = new userInfo();


        System.out.println(getOpening());
        int iData = obtainOpening();


        if (iData == 1) {
            init();
            obtainUserAmt();

            if (i == 1)
            {
                i = i + 1;
            }
            for (x = 0; x < i; x++){
                userId = obtainUserId();  //user id is created here
                userinfo.setUserId(userId); //userid is set for later output
                userPassword = obtainPassword(); //password is created here
                userinfo.setPassword(userPassword); //password is set for output later



                System.out.println(getString()); //this prints a message that lets the user know the account is succesfully created

                loginAttemptUserName(); //login attempt for username

                loginAttemptPassword(); //login attempt for password

                System.out.println(getLoggedIn()); //login completed here

                setMealPlan = getUserInfo1(); //user info is chosen here
                userinfo.setUserStatus(setMealPlan); //user info is set for dat file output

                setUserProgram = (char) getUserInfo2(); //user info program is chosen here
                userinfo.setUserProgram(setUserProgram); //user info is set for dat file output

                userInfo overrideInfo = new userInfo(userId, userPassword, setMealPlan, setUserProgram); //data is overridden

                output(); //outputs data to dat file
            }

            closeDat(); //dat file gets closed

            System.out.println(getEarlyClosing()); //closing message
        }

        if (iData == 2) {

            readDatFile();
            System.out.println(getEarlyClosing());

        }


        if (iData == 3) {

            System.out.println(getEarlyClosing());

        }


    }

    public static String getOpening() {

        return "Welcome, in this program you can make an account, type [1] if you would like to create an account" + '\n'
                + "If you would like to review created accounts type [2] " + '\n'
                + "If you do not wish to create an account or review, press [3] if you would like to exit";
    }

    public static String getEarlyClosing(){
        return "Thank you for using this program, have a nice day" + '\n' +
                "The amount of users in this program: " + ctr;
    }




    public static void init(){
        scanner = new Scanner(System.in);
        try {
            pw = new PrintWriter(new FileOutputStream(new File("myFile.dat"), true));
        }
        catch(FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "File Error");
        }
    }

    public static int obtainOpening(){
        boolean Psctr = false;
        int iData = 0;
        while (!Psctr){
            try{
                System.out.println("Type here: ");
                iData = Integer.parseInt(scanner.nextLine());
            }
            catch (Exception e){
                System.out.println("Error");
            }
            if (iData == answer[0]){
                Psctr = true;
                break;
            }
            else
            if (iData == answer[1]){
                Psctr = true;
                break;
            }
            else
            if (iData == answer[2]){
                Psctr = true;
                break;
            }
            else
                System.out.println("Input is wrong, please choose 1,2 or 3");
        }
        return iData;
    }

    public static int obtainUserAmt(){
        valid = false;
        while (!valid){
            try {
                System.out.println("Type the amount of users that you want to create: ");
                int iData2 = Integer.parseInt(scanner.nextLine());
                i = iData2;
                ctr = i;
                valid = true;
            }
            catch (Exception e)
            {
                System.out.println("error, please try again: ");
            }
        }
        return i;
    }

    public static String getString() {
        return "Account info{" +
                "user name='" +  userId + '\'' +
                " password ='" + userPassword + '\'' +
                '}';
    }

    public static String obtainUserId(){
        boolean Usctr = false;
        while (!Usctr){
            System.out.println("Enter Username (Between 6-10 letters and 2 digits): ");
            String iData = scanner.nextLine();
            try{
                if (iData.matches("[a-zA-Z]{6,10}[0-9]{2}")){
                    if (iData.matches(".*[a-z].*") && iData.matches(".*[A-Z].*") && iData.matches(".*[0-9].*")){
                        System.out.println("User name is valid");
                        Usctr = true;
                        userId = String.valueOf(iData);
                    }
                }
                if (!iData.matches("[a-zA-Z]{6,10}[0-9]{2}")){
                    System.out.println("invalid, please re-enter ");
                }
            }
            catch (Exception e){
                System.out.println("invalid");
            }

        }
        return userId;
    }

    public static String obtainPassword(){
        boolean Psctr = false;
        while (!Psctr){
            System.out.println("Enter password (Between 6-12 letters with 1 capital, 1 digit no white space or symbols): ");
            String iData = scanner.nextLine();
            try{
                if (iData.matches("[a-zA-Z0-9]{6,12}")){
                    if (iData.matches(".*[a-z].*") && iData.matches(".*[A-Z].*") && iData.matches(".*[0-9].*")) {
                        System.out.println("Password is valid");
                        Psctr = true;
                        userPassword = iData;
                    }
                }
                if (!iData.matches("[a-zA-Z0-9]{6,12}")){
                    System.out.println("password invalid, please re enter");
                }
            }
            catch (Exception e){
                System.out.println("invalid");
            }
        }

        return userPassword;
    }

    public static void loginAttemptUserName(){
        boolean Usctr = false;
        while (!Usctr){
            String userNameValidation = userId;
            System.out.println("Please enter your username:");
            String iData = scanner.nextLine();
            try{
                if (iData.matches(userNameValidation)){
                    System.out.println("Username is correct");
                    Usctr = true;
                }
                if (!iData.matches(userNameValidation)){
                    System.out.println("Username is incorrect");
                }
            }
            catch (Exception e){
                System.out.println("Username is wrong, try again");
            }


        }

    }

    public static void loginAttemptPassword(){
        boolean Psctr = false;
        while (!Psctr){
            String passwordValidation = userPassword;
            System.out.println("Please enter your password:");
            String iData = scanner.nextLine();
            try{
                if (iData.matches(passwordValidation)){
                    System.out.println("password is correct");
                    Psctr = true;
                }
                if (!iData.matches(passwordValidation)){
                    System.out.println("password is incorrect");
                }
            }
            catch (Exception e){
                System.out.println("password is wrong, try again");
            }


        }

    }

    public static String getLoggedIn() {
        return "You have logged into your account";
    }


    public static int getUserInfo1() {
        valid = false;

        System.out.println("Please enter what meal plan you have (Enter 1-3) \n" +
                "enter 1 if you are a Commuter no meal plan \n" +
                "enter 2 if you are a Commuter with meal plan \n" +
                "enter 3 if you are in a dorm \n");
        while (!valid) {
            String iData = scanner.nextLine();
            try {
                if (iData.equals("1")) {
                    setMealPlan = 1;
                    System.out.println("valid number");
                    valid = true;
                } else if (iData.matches("2")) {
                    setMealPlan = 2;
                    valid = true;
                } else if (iData.matches("3")) {
                    setMealPlan = 3;
                    valid = true;
                }
                else {
                    System.out.println("Invalid number");
                }
            } catch (Exception e) {
                System.out.println("Invalid number");
            }

        }
        return setMealPlan;
    }

    private static int getUserInfo2 () {
        valid = false;

        System.out.println("Please enter what program you are in \n" +
                "enter B if you are apart of the Business program  \n" +
                "enter L if you are apart of the Lasers program \n" +
                "enter N if you are apart of the Networking program\n" +
                "Enter P if you are apart of the Programming program\n" +
                "Enter R if you are apart of the Robotics program\n" +
                "Enter S if you are apart of the Social Media program\n");

        while (!valid) {
            char iData = scanner.nextLine().toUpperCase().charAt(0);
            try{
                switch (iData) {
                    case 'B':
                        valid = true;
                        setUserProgram = 'B';
                        break;
                    case 'L':
                        valid = true;
                        setUserProgram = 'L';
                        break;
                    case 'N':
                        valid = true;
                        setUserProgram = 'N';
                        break;
                    case 'P':
                        valid = true;
                        setUserProgram = 'P';
                        break;
                    case 'R':
                        valid = true;
                        setUserProgram = 'R';
                        break;
                    case 'S':
                        valid = true;
                        setUserProgram = 'S';
                        break;
                }

            }
            catch (Exception e){
                valid = false;
                System.out.println("Error: Try again.");
            }

        }
        return setUserProgram;
    }


    public static void output(){
        String record;
       // setMealPlan = Integer.toString(setMealPlan);
        record = String.format("%-12s%-12s%-1s%-1s%n", userInfo.getUserId(), userInfo.getUserPassword(), userInfo.getUserStatus(), userInfo.getUserProgram());
        pw.println(record);
        System.out.println("Users have been accepted. Press enter to continue. ");
        scanner.nextLine();

    }

    public static void readDatFile() throws FileNotFoundException {
            recordScanner = new Scanner(new File("myFile.dat"));
            if(recordScanner.hasNext()){
                String record = recordScanner.nextLine();
                iUsername = record.substring(0, 12);
                iPassword = record.substring(12, 24);
                iMealPlan = record.substring(24, 25);
                iStatus = record.substring(25, 26);
            }
            else {
                eof = true;
            }

            System.out.println("UserName    " + "Password    " + "Status                                    " + "Program");
            Scanner file = new Scanner(new File ("myFile.dat"));
            String open = file.nextLine();
            System.out.println(open);
        //for (x=0; x < 3; x++) {
            if (iMealPlan.equals("1")){
                System.out.println(mealPlan[0]);
            }
            if (iMealPlan.equals("2")){
                System.out.println(mealPlan[1]);
            }
            if (iMealPlan.equals("3")){
                System.out.println(mealPlan[2]);
            }
        switch (iStatus) {
            case "B":
                System.out.println(userProgram[0]);
                break;
            case "L":
                System.out.println(userProgram[1]);
                break;
            case "N":
                System.out.println(userProgram[2]);
                break;
            case "P":
                System.out.println(userProgram[3]);
                break;
            case "R":
                System.out.println(userProgram[4]);
                break;
            case "S":
                System.out.println(userProgram[5]);
                break;
        }
        //}



    }

    public static void closeDat() {
        pw.close();
    }
}