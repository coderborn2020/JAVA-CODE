class userInfo
{
        private static String userPassword;
        private static String userId;
        private static int setMealPlan;
        private static char userProgram;

        public userInfo(){
                userId = "Mohawk55";
                userPassword = "Moravia5";
                setMealPlan = 1;
                userProgram = 'B';
                }

         public userInfo(String user, String password, int meal, char program){
                 userId = user;
                 userPassword = password;
                 setMealPlan = meal;
                 userProgram = program;

         }

        public static String getUserId(){ return userId;}


        public void setUserId(String username) { userId = username; }

        public static String getUserPassword(){ return userPassword;}

        public void setPassword(String password)
                {
                userPassword = password;
                }



                public static int getUserStatus() {return setMealPlan;}



                public static char getUserProgram() {return userProgram;}

        public void setUserProgram(char program) { userProgram = program; }

        public void setUserStatus(int meal) {setMealPlan = meal;}


        public String overrideString() {

                return userPassword + userId + setMealPlan + userProgram;
        }



}
