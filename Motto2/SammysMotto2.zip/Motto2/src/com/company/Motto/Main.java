package com.company.Motto;

public class Main {

    public static void main(String[] args) {
        System.out.println("ssssssssssssssssssssssssssssssssssss");
        System.out.println("s                                  s");
	    System.out.println("s Sammy’s makes it fun in the sun. s");
        System.out.println("s                                  s");
        System.out.println("ssssssssssssssssssssssssssssssssssss");

    }
}
