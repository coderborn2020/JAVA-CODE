import java.util.Scanner;

class userInfo
{
        static Scanner scanner = new Scanner(System.in);
        private String userPassword;
        private String passwordValidation;
        private String userNameValidation;
        private String userId;
        public static int access;
        public static int exit;
        private int Psctr;
        private int Usctr;

        public userInfo(){
                Psctr = 0;
                Usctr = 0;
                }


        public String getOpening() {
                return "Welcome, in this program you can make an account, type [1] if you would like to create an account" + '\n'
                        + "If you do not wish to create an account, press [3] if you would like to exit";
        }

        public <access, exit> int getOpening2(){
                Psctr = 0;
                while (Psctr == 0){
                        System.out.println("Type here: ");
                        String iData = scanner.nextLine();
                        if (iData.matches("1")){
                                access = access + 1;
                                Psctr = Psctr + 1;
                                return access;
                        }
                        else
                                if (iData.matches("3")){
                                        exit = exit + 1;
                                        Psctr = Psctr + 1;
                                        return exit;
                                }
                                else
                                        if (!iData.matches("1")|!iData.matches("3")){
                                                System.out.println("Input is wrong, please choose 1 or 3");
                                        }

                }


                return access;
        }

        public String getEarlyClosing(){
                return "Thank you for using this program, have a nice day";
        }

        public void setUserId(String username)
                {
                userId = username;
                }

        public String getUserId(){
                Usctr = 0;
                while (Usctr == 0){
                System.out.println("Enter Username: ");
                String iData = scanner.nextLine();
                try{
                        if (iData.matches("[a-zA-Z]{6,10}[0-9]{2}")){
                                if (iData.matches(".*[a-z].*") && iData.matches(".*[A-Z].*") && iData.matches(".*[0-9].*")){
                                        System.out.println("User name is valid");
                                        Usctr = Usctr + 1;
                                        userId = String.valueOf(iData);
                                }
                        }
                        if (!iData.matches("[a-zA-Z]{6,10}[0-9]{2}")){
                                System.out.println("invalid, please re-enter ");
                        }
                }
                        catch (Exception e){
                                System.out.println("invalid");
                        }

                }
                return userId;
        }

        public void setPassword(String password)
                {
                userPassword = password;
                }

        public String getPassword(){
                Psctr = 0;
                while (Psctr == 0){
                System.out.println("Enter password: ");
                String iData = scanner.nextLine();
                        try{
                                if (iData.matches("[a-zA-Z0-9]{6,12}")){
                                        if (iData.matches(".*[a-z].*") && iData.matches(".*[A-Z].*") && iData.matches(".*[0-9].*")) {
                                                System.out.println("Password is valid");
                                                Psctr = Psctr + 1;
                                                userPassword = String.valueOf(iData);
                                        }
                                }
                                if (!iData.matches("[a-zA-Z0-9]{6,12}")){
                                        System.out.println("password invalid, please re enter");
                                }
                        }
                        catch (Exception e){
                                System.out.println("invalid");
                        }
                }

                return userPassword;
        }




        public String getString() {
                return "Account info{" +
                "user name='" +  userId + '\'' +
                " password ='" + userPassword + '\'' +
                '}';
                }


                public void  loginAttemptUserName(){
                        Usctr = 0;
                        while (Usctr == 0){
                                userNameValidation = userId;
                                System.out.println("Please enter your username:");
                                String iData = scanner.nextLine();
                                try{
                                        if (iData.matches(userNameValidation)){
                                                System.out.println("Username is correct");
                                                Usctr = Usctr + 1;
                                        }
                                        if (!iData.matches(userNameValidation)){
                                                System.out.println("Username is incorrect");
                                        }
                        }
                                catch (Exception e){
                                        System.out.println("Username is wrong, try again");
                                }


                }

        }

        public void  loginAttemptPassword(){
                Psctr = 0;
                while (Psctr == 0){
                        passwordValidation = userPassword ;
                        System.out.println("Please enter your password:");
                        String iData = scanner.nextLine();
                        try{
                                if (iData.matches(passwordValidation)){
                                        System.out.println("password is correct");
                                        Psctr = Psctr + 1;
                                }
                                if (!iData.matches(passwordValidation)){
                                        System.out.println("password is incorrect");
                                }
                        }
                        catch (Exception e){
                                System.out.println("password is wrong, try again");
                        }


                }

        }

        public String getClosing() {
                return "You have logged into your account";
        }
}
