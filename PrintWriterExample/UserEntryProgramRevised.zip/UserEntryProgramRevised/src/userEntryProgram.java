

public class userEntryProgram {

    public static void main(String[] args){
        int accessor = 0;
        int exit = 0;

        userInfo userinfo = new userInfo();



        System.out.println(userinfo.getOpening());
        userinfo.getOpening2();
        accessor = userinfo.access;
        exit = userinfo.exit;

        if (accessor == 1){
            userinfo.getPassword();
            userinfo.getUserId();
            System.out.println(userinfo.getString());
            userinfo.loginAttemptUserName();
            userinfo.loginAttemptPassword();
            System.out.println(userinfo.getClosing());
        }


        if (exit == 1){
            System.out.println(userinfo.getEarlyClosing());
        }






    }
}